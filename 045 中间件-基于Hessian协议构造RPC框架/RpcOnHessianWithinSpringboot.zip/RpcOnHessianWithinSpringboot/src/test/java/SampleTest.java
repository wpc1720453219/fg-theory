
 
import org.junit.Assert;
import org.junit.Test;
 
/**
 * Created by rosedoria on 2018/8/28.
 */
public class SampleTest {
 
    @Test
    public void testMethodOne(){
        Assert.assertTrue(true);
    }
 
    @Test
    public void testMethodTwo(){
        Assert.assertTrue(true);
    }
}
 
