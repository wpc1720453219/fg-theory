package hessian;

public interface Hello {

	public String sayHello(String msg);

}