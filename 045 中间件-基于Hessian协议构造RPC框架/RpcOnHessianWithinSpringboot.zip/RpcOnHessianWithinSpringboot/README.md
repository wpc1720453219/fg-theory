1===可参考文档===
@RequestMapping(value = "/relationsOfApplication", method = { RequestMethod.PUT }) @ResponseBody public ResponseEntity<?> uploadExcelFileWithApplicationDependencies(@RequestParam("file1") MultipartFile file, HttpServletRequest request) throws Exception {

http://www.cnblogs.com/alantong08/p/7099468.html
http://blog.csdn.net/clementad/article/details/52035199

常用配置 https://docs.spring.io/spring-boot/docs/current/reference/html/common-application-properties.html

https://blog.csdn.net/xmh594603296/article/details/79566986

https://blog.csdn.net/u011410529/article/details/66974974

===可参考文档===
#MySpringBoot

当前功能:

1)支持端口修改

2)网络引擎为Undertow

3)支持全局Listener监听器定义

4)支持Filter过滤器定义

5)支持controller编写

6)支持Bean定义

      6.1)支持属性注入

7)MVC框架集成(支持thymeleaf模板)

8)支持静态文件



#TODO

1)JQueryEasyUI接入

2)LayUI接入

3)Bootstrap接入

4)ECharts接入

5)Flowchart接入

6)FreeMarker支持

7)VUE框架接入

8)支持slf4j & logback

9)TinyMCE |Quill|CKEditor

https://github.com/spring-projects/spring-boot/releases
